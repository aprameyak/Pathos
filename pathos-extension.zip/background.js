chrome.runtime.onInstalled.addListener(() => {
    console.log('Screen Emotion Detector extension installed');
  });